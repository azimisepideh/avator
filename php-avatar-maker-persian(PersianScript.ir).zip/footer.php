            </div>
        <div id="Footer">
		<!---  ای بی مرام! میخوای حذف کنی؟ اذیتت میکنه؟ -->
            <p class="Copyright">ترجمه اسکریپت توسط <a href="http://www.persianscript.ir" target="_blank">پرشین اسکریپت</a></p>
        </div>
	</body>
</html>


